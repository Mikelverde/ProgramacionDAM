package pkg58_equals_compareto;

public class Prueba {

    public static void main(String[] args) {
        Direccion d = new Direccion("España", "mentiras", 1, "Ciudad real");

        Aeropuerto a1 = new Aeropuerto("Quijote airport", d, 1970, 1000);

        Aeropuerto a2 = new Aeropuerto("Adolfo Suarez", 
                        "España", "calle", 1, "Madrid", 2000, 250000);
        
        if(a1.equals(a2)){
            System.out.println("Son iguales");
        }else{
            System.out.println("No son iguales");
        }
        
        // Teniendo como referencia el primero
        // a1 < a2 = -1
        // a1 > a2 = 1
        // a1 == a2 = 0        
        
        switch(a1.compareTo(a2)){
            case 1:
                System.out.println("a1 es mayor que a2");
                break;
            case 0:
                System.out.println("a1 es igual que a2");
                break;
            case -1:
                System.out.println("a1 es menor que a2");
                break;
        }
        
        
    }

}
