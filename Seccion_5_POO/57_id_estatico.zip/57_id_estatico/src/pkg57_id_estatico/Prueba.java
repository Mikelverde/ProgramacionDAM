package pkg57_id_estatico;

public class Prueba {

    public static void main(String[] args) {
     
        Direccion d = new Direccion("España", "mentiras", 1, "Ciudad real");

        Aeropuerto a1 = new Aeropuerto("Quijote airport", d, 2000, 1000);
        
        Aeropuerto a2 = new Aeropuerto("Quijote airport", d, 2000, 1000);
        
        Aeropuerto a3 = new Aeropuerto("Quijote airport", d, 2000, 1000);
        
        Aeropuerto a4 = new Aeropuerto("Quijote airport", d, 2000, 1000);
        
        Aeropuerto a5 = new Aeropuerto("Quijote airport", d, 2000, 1000);
        
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);
        System.out.println(a4);
        System.out.println(a5);
        
    }
    
}
