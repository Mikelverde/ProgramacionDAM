package pkg63_abtraccion;

public class Prueba {
    
    public static void main(String[] args) {
        
        Direccion d = new Direccion("España", "mentiras", 1, "Ciudad real");
        
        AeropuertoPrivado a1 = new AeropuertoPrivado(5, "Quijote airport", d, 1970, 1000);

        AeropuertoPublico a2 = new AeropuertoPublico(100000, 10, "Adolfo Suarez",
                "España", "calle", 1, "Madrid", 2000, 250000);
        
        a1.gananciasTotales(1000000);
        
        a2.gananciasTotales(1000000);
        
    }
    
}
